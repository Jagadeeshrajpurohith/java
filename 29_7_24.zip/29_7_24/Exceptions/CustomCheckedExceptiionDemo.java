public class CustomCheckedExceptiionDemo {

    public static void main(String[] args) {
       try{
           dosomething();
       }
       catch (CustomCheckedException e){
//           System.out.println("custom checked exception");
           System.err.print("custom checked exception"+e.getMessage());
       }
    }
    public static void dosomething() throws CustomCheckedException{
        throw new CustomCheckedException("custom checked exception");
    }
}
