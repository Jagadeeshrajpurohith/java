import java.util.List;
import java.util.Objects;

public class CustomUncheckedExceptionDemo {
    public static void main(String[] args) {

        try{
            String s1="hello";
            String s2="hello";
            System.out.println(s1==s2);
            System.out.println(s1.equals(s2));
            System.out.println(s1.equals(s2.toUpperCase()));
            System.out.println(s1==s2);
            System.out.println(s1.equals(s2));
            dosomething();
//            System.exit(0);
        }
        catch (CustomUncheckedException e){
            System.out.println("custom unchecked exception");
        }
    }
    public static void dosomething(){
        throw new CustomUncheckedException("custom unchecked exception");
    }
//    Object obj=new Objects();
//    final object obj=new Object();
//    comparable obj=new comparable();


}
