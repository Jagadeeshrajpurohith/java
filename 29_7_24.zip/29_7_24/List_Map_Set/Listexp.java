import java.util.*;
public class Listexp {


    public static void main(String[] args) {
        Map<Employee, String> map = new HashMap<>();
        map.put(new Employee("sai", 29), "sai");
        map.put(new Employee("jagadeesh", 28), "jagadeesh");
        map.put(new Employee("varun", 25), "varun");
        map.put(new Employee("prasad", 26), "prasad");

        for (Map.Entry<Employee, String> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " " + entry.getValue());
        }

        List<Employee> list = new ArrayList<>();
        list.add(new Employee("sai", 29));
        list.add(new Employee("jagadeesh", 28));
        list.add(new Employee("varun", 25));
        list.add(new Employee("prasad", 26));
        Collections.sort(list, Comparator.comparing(Employee::getAge));
        list.sort(Collections.reverseOrder(Comparator.comparing(Employee::getAge)));

        for (Employee emp : list) {
            System.out.println(emp);
        }

        Set<Employee> set = new HashSet<>();
        set.add(new Employee("sai", 29));
        set.add(new Employee("jagadeesh", 28));
        set.add(new Employee("varun", 25));
        set.add(new Employee("prasad", 26));

        Employee emp1 = new Employee("saii", 59);
        Employee emp2 = new Employee("saii", 59);

        if (emp1.hashCode() == emp2.hashCode()) {
            System.out.println("same");
        } else {
            System.out.println("not same");
        }

        System.out.println(emp1.hashCode());
        System.out.println(emp2.hashCode());

        set.add(emp1);
        set.add(emp2);

        System.out.println(set);
    }
}