import java.util.Objects;

public class Employee {
    String name;
    int age;
    public Employee(String name,int age){
        this.name=name;
        this.age=age;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public String toString(){
        return name+" "+age;
    }
    @Override
    public int hashCode(){
        return Objects.hash(name,age);
    }


}
