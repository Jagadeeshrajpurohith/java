import java.io.IOException;

public  class Animal {

    public Number eat()   throws IOException {
        System.out.println("I am eating");
        return 9;
    }

}
