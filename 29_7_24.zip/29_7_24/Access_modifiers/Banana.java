public class Banana implements Fruit {

    @Override
    public void color() {
        System.out.println("banana color is yellow");
    }
}
