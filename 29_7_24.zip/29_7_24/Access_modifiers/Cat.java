import java.io.IOException;

public class Cat extends Animal {

    @Override
    public Float eat() throws IOException {
        System.out.println("hdjw");
        return 0.0f;
    }
}
